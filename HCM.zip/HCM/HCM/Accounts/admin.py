from django.contrib import admin
from .models import Hospital, Appointment, Department, Location, Transaction, UserProfile, DoctorProfile


class HospitalAdmin(admin.ModelAdmin):
    list_display = ('name', 'location', 'contact', 'email')


class AppointmentAdmin(admin.ModelAdmin):
    list_display = ('appointment_id', 'user', 'doctor', 'appointment_time', 'status', 'fee')


class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('department_id', 'department_name')


class LocationAdmin(admin.ModelAdmin):
    list_display = ('location_id', 'location_name')


class TransactionAdmin(admin.ModelAdmin):
    list_display = ('from_user', 'to_user', 'amount', 'success')


class DoctorProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'hospital', 'contact', 'specialization')


class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'contact', 'address', 'birth_date')


admin.site.register(UserProfile, UserProfileAdmin)
admin.site.register(DoctorProfile, DoctorProfileAdmin)

admin.site.register(Hospital, HospitalAdmin)
admin.site.register(Appointment, AppointmentAdmin)
admin.site.register(Department, DepartmentAdmin)
admin.site.register(Location, LocationAdmin)
admin.site.register(Transaction, TransactionAdmin)
