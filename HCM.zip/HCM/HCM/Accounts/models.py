from datetime import datetime
from django.contrib.auth.models import User
from django.urls import reverse
from django.db import models, transaction


# Create your models here.
class Location(models.Model):
    location_id = models.AutoField(primary_key=True)
    location_name = models.CharField(max_length=500)

    def __str__(self):
        return self.location_name


class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    contact = models.CharField(max_length=50)
    address = models.CharField(max_length=500, blank=True)
    birth_date = models.DateField(blank=True)
    amount = models.PositiveIntegerField(default=1500)

    def get_absolute_url(self):
        return reverse('account:user', kwargs={'pk': self.pk})

    def __str__(self):
        return self.user.username


class DoctorProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    hospital = models.ForeignKey('Accounts.Hospital', on_delete=models.CASCADE)
    contact = models.CharField(max_length=50)
    specialization = models.ForeignKey('Accounts.Department', on_delete=models.CASCADE)
    consultation_fee = models.IntegerField(default=200)
    amount = models.PositiveIntegerField(default=100)

    def get_absolute_url(self):
        return reverse('account:user', kwargs={'pk': self.pk})

    def __str__(self):
        return self.user.username


class Hospital(models.Model):
    name = models.CharField(max_length=100, primary_key=True)
    location = models.ForeignKey(Location, on_delete='cascade')
    contact = models.CharField(max_length=100, default='123456789')
    email = models.CharField(max_length=100, default='hospital_email@gmail.com')
    amount = models.PositiveIntegerField(default=100)

    def __str__(self):
        return self.name


class Department(models.Model):
    department_id = models.AutoField(primary_key=True)
    department_name = models.CharField(max_length=500)

    def __str__(self):
        return self.department_name


class Transaction(models.Model):
    from_user = models.ForeignKey(User, related_name='from_user', on_delete='cascade')
    to_user = models.ForeignKey(User, related_name='to_user', on_delete='cascade')
    time = models.DateTimeField(default=datetime, primary_key='True' )
    amount = models.PositiveIntegerField()
    reason = models.CharField(max_length=100)
    success = models.BooleanField(default=False)

    @transaction.atomic
    def make_transaction(self, from_user, to_user, amount, reason):
        status = False
        if from_user.amount >= amount:
            from_user.amount -= amount
            to_user.amount += amount
            from_user.save()
            to_user.save()
            status = True
        transaction = Transaction(from_user=from_user.user, to_user=to_user.user, amount=amount, success=status,
                                  reason=reason)
        transaction.save()
        return transaction, status

    def get_absolute_url(self):
        return reverse('Accounts:transaction-detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.id) + ': ' + str(self.from_user) + ' to ' + str(self.to_user) + ' - ' + str(self.amount)


class Appointment(models.Model):
    STATUS = (
        ('Unconfirmed', 'Unconfirmed'),
        ('Confirmed', 'Confirmed'),
    )
    appointment_id = models.AutoField(primary_key=True)
    transaction_id = models.ForeignKey(Transaction, on_delete='cascade')
    user = models.ForeignKey(User, on_delete='cascade')
    doctor = models.ForeignKey(DoctorProfile, on_delete='cascade')
    booking_time = models.DateTimeField(default=datetime.now)
    appointment_date = models.DateField()
    appointment_time = models.TimeField(blank=True, null=True)
    prescription = models.TextField(default='Prescription will be filled by the doctor.')
    status = models.CharField(max_length=20, default='Unconfirmed', choices=STATUS)
    fee = models.PositiveIntegerField(default=500)

    def get_absolute_url(self):
        return reverse('Accounts:appointment-detail', kwargs={'pk': self.pk})

    def __str__(self):
        return str(self.appointment_id) + ': ' + self.user.username + ' - ' + self.doctor.user.username
